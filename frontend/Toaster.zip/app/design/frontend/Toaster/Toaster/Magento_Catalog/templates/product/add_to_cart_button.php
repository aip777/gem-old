<div class="add-to-cart">
<button type="submit"title="<?php echo $block->escapeHtml(__('Add to Cart')); ?>"class="btn btn-primary action tocart"><span><?php /* @escapeNotVerified */ echo __('Add to Cart') ?></span></button>
</div>
