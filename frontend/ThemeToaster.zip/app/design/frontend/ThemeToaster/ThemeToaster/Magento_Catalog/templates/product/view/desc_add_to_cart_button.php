<button type="submit"title="<?php /* @escapeNotVerified */ echo $buttonTitle ?>"class="btn btn-primary action primary tocart"id="product-addtocart-button">
<span><?php /* @escapeNotVerified */ echo $buttonTitle ?></span> </button>
