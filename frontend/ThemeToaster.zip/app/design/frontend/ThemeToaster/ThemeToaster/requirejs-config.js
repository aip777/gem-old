// File: app/design/frontend/Vendor/theme/requirejs-config.js
var config = {
 deps: [
 'js/bootstrap.min',
 'js/customjs',
 'js/html5shiv'
,
 'js/totop'
,
'js/tt_slideshow'
]
};
